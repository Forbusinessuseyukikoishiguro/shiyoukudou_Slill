# 例

## 例1：不具合修正（小）

差分の要点：ログイン失敗時、`error.message` が undefined で空のエラーが表示される。`error.response?.data?.message` を参照するよう変更。

GitHub用
```
ログイン失敗時にエラーメッセージが空になる不具合を修正

APIのエラー本文は error.response.data.message に入っており、
error.message を参照していたため未定義になっていた。
参照先を修正し、取得できない場合は既定の文言を表示する。

Fixes #128
```

メモ用
```
【変更】ログイン失敗時のエラー表示を修正
【理由】error.message が undefined で空表示になっていた
【影響】ログイン画面のみ。他画面のエラー表示は未確認
【未了・確認】他画面で同じ参照をしていないか grep する
【関連】#128 / fix/login-error
```

## 例2：機能追加（設定追加を含む）

GitHub用
```
CSVエクスポートに文字コード指定オプションを追加

Excelで開く利用者が文字化けする問い合わせが多いため、
UTF-8（BOM付き）とShift_JISを選択できるようにした。
既定はUTF-8（BOM付き）に変更。

- 環境変数 EXPORT_DEFAULT_ENCODING を追加（未設定時は utf-8-sig）
- 既存のUTF-8（BOMなし）出力は encoding=utf-8 で指定可能

BREAKING CHANGE: 既定の出力がBOM付きUTF-8に変わる。
BOMなしが必要な連携先は encoding=utf-8 を指定すること。
```

## 例3：整形のみ

GitHub用
```
フォーマッタ適用によるインデントと import 順の整理

挙動の変更なし。
```

## 例4：混在していた場合の分割案

```
分割案
1. 整形のみ（src/utils/*.ts）→ 「Prettier適用によるコード整形」
2. 機能追加（src/export/csv.ts, 設定）→ 「CSVエクスポートに文字コード指定を追加」
3. 依存更新（package.json, lock）→ 「csv-writer を x.y.z に更新」
```

## 例5：意図が差分から読めない場合

```
要確認
- config/limits.ts の MAX_ROWS が 1000 → 5000 に変更されているが、理由が差分から読み取れない。
  性能上の問題か仕様変更か教えてください。教えてもらえれば本文に反映します。
```
