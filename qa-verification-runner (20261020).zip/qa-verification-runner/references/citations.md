# 引用バンク（査読済み論文）

注意：書誌情報は作成時の知識に基づく。商用公開（Kindle・Qiita・研修資料）で引用する前に、DOI/出版社ページで巻号・ページを必ず再確認すること。確認できない情報は書かない。

## カバレッジ・テスト有効性

C1. Inozemtseva, L., & Holmes, R. (2014). Coverage is not strongly correlated with test suite effectiveness. Proc. ICSE 2014.
- 知見：スイート規模を統制すると、カバレッジと欠陥検出力（変異検出）の相関は弱〜中程度。
- 使い所：「カバレッジ◯%を目標にしない」「穴を探す道具として使う」根拠。

C2. Gopinath, R., Jensen, C., & Groce, A. (2014). Code coverage for suite evaluation by developers. Proc. ICSE 2014.
- 知見：カバレッジと変異スコアには相関があり、文カバレッジが比較的よい予測因子。
- 使い所：C1と併記し「低カバレッジは弱いシグナル、高カバレッジは十分条件ではない」と釣り合いを取る。

C5. Just, R., Jalali, D., Inozemtseva, L., Ernst, M. D., Holmes, R., & Fraser, G. (2014). Are mutants a valid substitute for real faults in software testing? Proc. FSE 2014.
- 知見：変異テストは実バグ検出力の指標として有効だが、全ての実バグを模倣できるわけではない。
- 使い所：重要モジュールに限った変異テスト提案の根拠。

## 回帰テスト

C3. Rothermel, G., & Harrold, M. J. (1996). Analyzing regression test selection techniques. IEEE Transactions on Software Engineering, 22(8).
- 使い所：変更差分に基づく回帰テスト選択の評価観点（包含性・精度・効率・一般性）。

C4. Yoo, S., & Harman, M. (2012). Regression testing minimization, selection and prioritization: a survey. Software Testing, Verification and Reliability, 22(2).
- 使い所：テストの最小化・選択・優先度づけの全体像。回帰テスト計画の根拠。

C10. Memon, A., et al. (2017). Taming Google-scale continuous testing. Proc. ICSE-SEIP 2017.
- 使い所：継続的テストの実運用（変更に関連するテストの選択、失敗の扱い）。大規模事例である点を断る。

## フレイキーテスト

C6. Luo, Q., Hariri, F., Eloussi, L., & Marinov, D. (2014). An empirical analysis of flaky tests. Proc. FSE 2014.
- 知見：フレイキーの主因として、非同期待ち(async wait)、並行性、テスト順序依存などが多い。
- 使い所：フレイキー原因分類の根拠。

C7. Parry, O., Kapfhammer, G. M., Hilton, M., & McMinn, P. (2021). A survey of flaky tests. ACM Transactions on Software Engineering and Methodology, 31(1).
- 使い所：検出・原因・対処の体系的整理。

C11. Eck, M., Palomba, F., Castelluccio, M., & Bacchelli, A. (2019). Understanding flaky tests: the developer's perspective. Proc. ESEC/FSE 2019.
- 使い所：開発者が実際に直面する原因・影響の実務的視点。

## テストコード品質・自動化戦略

C8. Garousi, V., & Küçük, B. (2018). Smells in software test code: a survey of knowledge in industry and academia. Journal of Systems and Software, 138.
- 使い所：テストの臭い点検（Phase 2 4-4）。灰色文献を含むサーベイである旨に注意。

C9. Garousi, V., & Mäntylä, M. V. (2016). When and what to automate in software testing? A multi-vocal literature review. Information and Software Technology, 76.
- 使い所：自動化対象の選び方、E2Eを絞る判断。灰色文献を含むレビューである旨に注意。

## 使い方ルール

1. 引用は上記に記載したものだけ。新規追加は検索で書誌確認後に限る。
2. 「論文が証明した」と断定せず、「〜という知見が報告されている」と書く。
3. 調査対象（OSS/特定企業/言語）の範囲を外挿しすぎない。自社適用時は計測して確かめる。
