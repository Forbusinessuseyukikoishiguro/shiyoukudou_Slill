#!/usr/bin/env bash
# フレイキーテスト検出：同一テストコマンドをN回実行し、実行ごとの終了コードを集計する。
# 使い方: scripts/detect_flaky.sh <N> <テストコマンド...>
# 例:     scripts/detect_flaky.sh 10 npx vitest run
#         scripts/detect_flaky.sh 10 pytest -q -p no:randomly
# 出力:   qa-output/flaky-<timestamp>/run-<i>.log と summary.txt
# 注意:   テスト単位の不一致は各runのログ/JUnit XMLを比較して特定する（FW依存のため）。
#         本番環境では実行しないこと。
set -u
if [ $# -lt 2 ]; then
  echo "usage: $0 <N> <test command...>" >&2
  exit 2
fi
N="$1"; shift
case "$N" in (*[!0-9]*|'') echo "N must be a positive integer" >&2; exit 2;; esac
TS="$(date +%Y%m%d-%H%M%S)"
OUT="qa-output/flaky-${TS}"
mkdir -p "$OUT"
pass=0; fail=0
for i in $(seq 1 "$N"); do
  "$@" > "$OUT/run-${i}.log" 2>&1
  rc=$?
  echo "run ${i}: exit=${rc}" | tee -a "$OUT/summary.txt"
  if [ "$rc" -eq 0 ]; then pass=$((pass+1)); else fail=$((fail+1)); fi
done
{
  echo "---"
  echo "total=${N} pass=${pass} fail=${fail}"
  if [ "$pass" -gt 0 ] && [ "$fail" -gt 0 ]; then
    echo "RESULT: UNSTABLE (flaky suspected). Compare run logs to identify tests."
  elif [ "$fail" -eq "$N" ]; then
    echo "RESULT: ALWAYS FAILING (deterministic failure, not flaky)"
  else
    echo "RESULT: STABLE in ${N} runs (flakiness not excluded)"
  fi
} | tee -a "$OUT/summary.txt"
[ "$fail" -eq 0 ]
