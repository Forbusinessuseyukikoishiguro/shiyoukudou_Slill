#!/usr/bin/env python3
"""selftest.py - spec_lint.py / trace_check.py の自己テスト。python scripts/selftest.py で実行。
点検ツール自体が壊れていないことを示す（過去に見つかった不具合の再発防止）。"""
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).parent


def run(script, *args):
    p = subprocess.run([sys.executable, str(HERE / script), *args], capture_output=True, text=True, encoding="utf-8")
    return p.returncode, p.stdout


def write(root, name, text):
    p = Path(root) / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")


GOOD_REQ = "## FR-001 読み込み\nシステムは、CSVを読み込まなければならない。\n- 受入基準：Given a / When b / Then c\n"


class LintTests(unittest.TestCase):
    def test_table_requirements_are_not_silently_accepted(self):
        with tempfile.TemporaryDirectory() as d:
            write(d, "s.md", "| ID | 要求 |\n|---|---|\n| FR-001 | システムは読む |\n")
            code, out = run("spec_lint.py", d)
            self.assertEqual(code, 1)
            self.assertIn("E003", out)

    def test_empty_acceptance_label_is_error(self):
        with tempfile.TemporaryDirectory() as d:
            write(d, "s.md", "## FR-001 読み込み\nシステムは、読み込まなければならない。\n- 受入基準：\n")
            code, out = run("spec_lint.py", d)
            self.assertEqual(code, 1)
            self.assertIn("E002", out)

    def test_missing_acceptance_is_error(self):
        with tempfile.TemporaryDirectory() as d:
            write(d, "s.md", "## FR-001 読み込み\nシステムは、読み込まなければならない。\n")
            self.assertEqual(run("spec_lint.py", d)[0], 1)

    def test_douto_not_flagged_but_nado_is(self):
        with tempfile.TemporaryDirectory() as d:
            write(d, "s.md", "## FR-001 同等性\nシステムは、既存と同等の結果を返さなければならない。\n- 受入基準：Given a / When b / Then c\n"
                             "## FR-002 例\nシステムは、CSVなどを読まなければならない。\n- 受入基準：Given a / When b / Then c\n")
            _, out = run("spec_lint.py", d)
            self.assertNotIn("曖昧語「等」", out)
            self.assertIn("曖昧語「など」", out)

    def test_duplicate_id(self):
        with tempfile.TemporaryDirectory() as d:
            write(d, "s.md", GOOD_REQ + GOOD_REQ)
            code, out = run("spec_lint.py", d)
            self.assertEqual(code, 1)
            self.assertIn("E001", out)

    def test_clean_spec_passes(self):
        with tempfile.TemporaryDirectory() as d:
            write(d, "s.md", "版: 0.1\n状態: 草案\n" + GOOD_REQ)
            self.assertEqual(run("spec_lint.py", d)[0], 0)

    def test_custom_prefix(self):
        with tempfile.TemporaryDirectory() as d:
            write(d, "s.md", GOOD_REQ.replace("FR-001", "SEC-001"))
            self.assertEqual(run("spec_lint.py", d)[0], 1)  # 既定の接頭辞では検出されない
            self.assertEqual(run("spec_lint.py", d, "--prefix", "SEC")[0], 0)


class TraceTests(unittest.TestCase):
    def _spec(self, d, n=3):
        write(d, "spec/s.md", "".join(
            f"## FR-00{i} 要求{i}\nシステムは、動かなければならない。\n- 受入基準：Given a / When b / Then c\n" for i in range(1, n + 1)))

    def test_id_next_to_japanese_particle_is_found(self):
        with tempfile.TemporaryDirectory() as d:
            self._spec(d, 1)
            write(d, "test/t.md", "# TC-001 確認\n- 対応要求：FR-001を検証\n")
            code, out = run("trace_check.py", "--spec", f"{d}/spec", "--test", f"{d}/test")
            self.assertEqual(code, 0, out)

    def test_table_only_reference_is_not_coverage(self):
        with tempfile.TemporaryDirectory() as d:
            self._spec(d, 1)
            write(d, "test/trace.md", "| 要求ID | テスト | 結果 |\n|---|---|---|\n| FR-001 | TC-009 | 未実施 |\n")
            code, out = run("trace_check.py", "--spec", f"{d}/spec", "--test", f"{d}/test")
            self.assertEqual(code, 1)
            self.assertIn("T001", out)
            self.assertIn("T004", out)

    def test_range_is_expanded(self):
        with tempfile.TemporaryDirectory() as d:
            self._spec(d, 1)
            write(d, "test/trace.md", "| FR-001 | CSV | TC-001〜TC-003 | 未実施 |\n")
            _, out = run("trace_check.py", "--spec", f"{d}/spec", "--test", f"{d}/test", "--md")
            self.assertIn("TC-002", out)

    def test_defs_from_code(self):
        with tempfile.TemporaryDirectory() as d:
            self._spec(d, 1)
            write(d, "test/trace.md", "| FR-001 | CSV | TC-001 | 未実施 |\n")
            write(d, "tests/test_csv.py", "def test_tc001():\n    '''TC-001'''\n")
            code, out = run("trace_check.py", "--spec", f"{d}/spec", "--test", f"{d}/test", "--defs-from", f"{d}/tests")
            self.assertEqual(code, 0, out)

    def test_unknown_requirement(self):
        with tempfile.TemporaryDirectory() as d:
            self._spec(d, 1)
            write(d, "test/t.md", "# TC-001 a\n- 対応要求：FR-001, FR-099\n")
            code, out = run("trace_check.py", "--spec", f"{d}/spec", "--test", f"{d}/test")
            self.assertEqual(code, 1)
            self.assertIn("T002", out)

    def test_no_requirements_is_error(self):
        with tempfile.TemporaryDirectory() as d:
            write(d, "spec/s.md", "| FR-001 | x |\n")
            write(d, "test/t.md", "# TC-001 a\n")
            self.assertEqual(run("trace_check.py", "--spec", f"{d}/spec", "--test", f"{d}/test")[0], 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
