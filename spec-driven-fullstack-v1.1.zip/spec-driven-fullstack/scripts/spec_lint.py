#!/usr/bin/env python3
"""spec_lint.py - 仕様書(.md)の機械的な点検。見落とし防止の補助であり、合否は判断しない。

使い方:
    python spec_lint.py docs/spec                   # 点検して一覧表示
    python spec_lint.py docs/spec --strict          # 警告もエラー扱い（終了コード1）
    python spec_lint.py docs/spec --json            # JSON出力
    python spec_lint.py docs/spec --prefix FR,NFR,SEC   # 要求IDの接頭辞を変更
    python spec_lint.py docs/spec --ignore-word 等  # 曖昧語の誤検出を除外

要求は「## FR-001 要求名」の見出し形式で書く（表やリスト形式の要求は検出できない）。

検出するもの:
    E000 仕様 .md が見つからない
    E001 要求IDの重複
    E002 受入基準がない、または中身が空
    E003 要求が1件も検出できない（見出し形式でない可能性。黙って合格にしない）
    W001 曖昧語（など／適切に／必要に応じて／速く 等）
    W002 義務表現がない（なければならない／ものとする／望ましい／てもよい／すること）
    I001 受入基準が Given/When/Then 形式でない
    I002 複合要求の可能性（および／かつ 等。単一性を人が確認）
    I003 文書の版・状態のメタ情報がない
    I004 未決事項の件数（概算）
"""
import argparse
import json
import re
import sys
from pathlib import Path

DEFAULT_PREFIXES = ["FR", "NFR", "IR", "CR", "SR"]
ANY_HEADING = re.compile(r"^(#{1,6})\s+\S")
FENCE = re.compile(r"^\s*(```|~~~)")

# 「等」は「同等」「平等」「等しい」などの誤検出が多いため、正規表現で除外する
AMBIGUOUS = [
    ("など", re.compile("など")),
    ("等", re.compile(r"(?<![同平対均一高初特優劣不何])等(?![しいじ])")),
    ("適切に", re.compile("適切に")), ("適宜", re.compile("適宜")),
    ("必要に応じて", re.compile("必要に応じて")),
    ("できるだけ", re.compile("できるだけ")), ("なるべく", re.compile("なるべく")),
    ("速く", re.compile("速く")), ("素早く", re.compile("素早く")), ("迅速", re.compile("迅速")),
    ("使いやすい", re.compile("使いやすい")),
    ("分かりやすい", re.compile("[分わ]かりやすい")),
    ("十分", re.compile("十分")), ("柔軟", re.compile("柔軟")),
    ("容易に", re.compile("容易に")), ("簡単に", re.compile("簡単に")),
    ("高速", re.compile("高速")), ("大量", re.compile("大量")), ("少量", re.compile("少量")),
    ("ある程度", re.compile("ある程度")), ("基本的に", re.compile("基本的に")),
    ("原則として", re.compile("原則として")), ("場合によって", re.compile("場合によって")),
    ("一般的に", re.compile("一般的に")),
]
OBLIGATION = ["なければならない", "ものとする", "望ましい", "てもよい", "すること"]
COMPOUND = ["および", "及び", "かつ", "ならびに", "並びに", "とともに"]
ACCEPT_MARK = re.compile(r"受入基準")
GIVEN = re.compile(r"\bgiven\b", re.I)


def read_text(path):
    return Path(path).read_text(encoding="utf-8-sig")  # Windowsのメモ帳のBOMに対応


def strip_code(lines):
    """コードブロックの中身を空行に置き換える（行番号は保つ）。"""
    out, in_fence = [], False
    for ln in lines:
        if FENCE.match(ln):
            in_fence = not in_fence
            out.append("")
            continue
        out.append("" if in_fence else ln)
    return out


def parse_requirements(path, req_heading):
    raw = read_text(path).splitlines()
    lines = strip_code(raw)
    reqs, cur = [], None
    for i, ln in enumerate(lines, start=1):
        m = req_heading.match(ln)
        if m:
            if cur:
                cur["end"] = i - 1
                reqs.append(cur)
            cur = {"id": m.group(2), "title": m.group(3).strip(), "line": i,
                   "level": len(m.group(1)), "body": [], "end": i}
            continue
        if cur and ANY_HEADING.match(ln):
            hl = len(ln) - len(ln.lstrip("#"))
            if hl <= cur["level"]:
                cur["end"] = i - 1
                reqs.append(cur)
                cur = None
                continue
        if cur:
            cur["body"].append((i, ln))
    if cur:
        cur["end"] = len(lines)
        reqs.append(cur)
    return raw, lines, reqs


def acceptance_text(body):
    """『受入基準』以降の実質的な中身（ラベルだけは空とみなす）を返す。"""
    m = ACCEPT_MARK.search(body)
    if not m:
        return None
    rest = body[m.end():]
    rest = re.sub(r"^[\s:：*_`-]+", "", rest)
    rest = re.sub(r"[\s\-*|>:：_`]+", "", rest)
    return rest


def lint(spec_dir, prefixes=None, ignore_words=()):
    prefixes = prefixes or DEFAULT_PREFIXES
    req_heading = re.compile(
        r"^(#{1,6})\s+((?:" + "|".join(re.escape(p) for p in prefixes) + r")-\d{1,6})(?![0-9A-Za-z])\s*(.*)$")
    findings = []
    files = sorted(Path(spec_dir).rglob("*.md"))
    if not files:
        findings.append({"level": "ERROR", "code": "E000", "file": str(spec_dir), "line": 0,
                         "message": "仕様 .md が見つかりません"})
        return findings, 0
    seen = {}
    total_reqs = 0
    open_items = 0
    amb = [(w, rx) for w, rx in AMBIGUOUS if w not in set(ignore_words)]
    for f in files:
        raw, lines, reqs = parse_requirements(f, req_heading)
        text_all = "\n".join(lines)
        if not re.search(r"^(版|状態)\s*[:：]", text_all, re.M):
            findings.append({"level": "INFO", "code": "I003", "file": str(f), "line": 1,
                             "message": "版・状態のメタ情報（版:／状態:）が見つかりません"})
        in_open = False
        for ln in lines:
            if re.match(r"^#{1,6}\s+.*未決事項", ln):
                in_open = True
                continue
            if in_open and ANY_HEADING.match(ln):
                in_open = False
            if in_open and re.match(r"^\s*([-*]|\|\s*Q-\d+|\d+\.)\s*\S", ln) and "---" not in ln:
                open_items += 1
        for r in reqs:
            total_reqs += 1
            rid = r["id"]
            if rid in seen:
                findings.append({"level": "ERROR", "code": "E001", "file": str(f), "line": r["line"],
                                 "message": f"{rid} が重複しています（先の定義: {seen[rid]}）"})
            else:
                seen[rid] = f"{f}:{r['line']}"
            body = "\n".join(t for _, t in r["body"])
            head_and_body = (r["title"] + "\n" + body)
            acc = acceptance_text(body)
            if acc is None and not GIVEN.search(body):
                findings.append({"level": "ERROR", "code": "E002", "file": str(f), "line": r["line"],
                                 "message": f"{rid} に受入基準がありません"})
            elif acc is not None and len(acc) < 3 and not GIVEN.search(body):
                findings.append({"level": "ERROR", "code": "E002", "file": str(f), "line": r["line"],
                                 "message": f"{rid} の受入基準が空です（ラベルだけで中身がありません）"})
            elif not GIVEN.search(body):
                findings.append({"level": "INFO", "code": "I001", "file": str(f), "line": r["line"],
                                 "message": f"{rid} の受入基準が Given/When/Then 形式ではありません"})
            if not any(w in head_and_body for w in OBLIGATION):
                findings.append({"level": "WARN", "code": "W002", "file": str(f), "line": r["line"],
                                 "message": f"{rid} に義務表現（しなければならない 等）がありません"})
            for lineno, t in r["body"]:
                for w, rx in amb:
                    if rx.search(t):
                        findings.append({"level": "WARN", "code": "W001", "file": str(f), "line": lineno,
                                         "message": f"{rid} に曖昧語「{w}」: {t.strip()[:60]}"})
                        break
            first = next((t for _, t in r["body"] if t.strip()), "")
            first_sentence = first.split("。")[0]
            hit = next((w for w in COMPOUND if w in first), None)
            if hit is None and re.search(r"[しみきりびちい]、", first_sentence):
                hit = "連用形の並列"
            if hit:
                findings.append({"level": "INFO", "code": "I002", "file": str(f), "line": r["line"],
                                 "message": f"{rid} は複合要求の可能性（{hit}）。単一か人が確認"})
    if total_reqs == 0:
        findings.append({"level": "ERROR", "code": "E003", "file": str(spec_dir), "line": 0,
                         "message": "要求が1件も検出できません。要求は「## FR-001 要求名」の見出し形式で書いてください"
                                    "（表・箇条書きの要求は検出できません）。接頭辞が違う場合は --prefix で指定"})
    findings.append({"level": "INFO", "code": "I004", "file": str(spec_dir), "line": 0,
                     "message": f"要求 {total_reqs} 件／未決事項 {open_items} 件（概算）"})
    return findings, total_reqs


def main():
    ap = argparse.ArgumentParser(description="仕様 .md の機械的な点検（補助）")
    ap.add_argument("spec_dir")
    ap.add_argument("--strict", action="store_true", help="警告もエラー扱いにする")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--prefix", default=",".join(DEFAULT_PREFIXES),
                    help="要求IDの接頭辞（カンマ区切り。既定: %(default)s）")
    ap.add_argument("--ignore-word", action="append", default=[], metavar="WORD",
                    help="曖昧語の検出から除外する語（複数指定可）")
    a = ap.parse_args()
    prefixes = [p.strip() for p in a.prefix.split(",") if p.strip()]
    findings, _ = lint(a.spec_dir, prefixes, a.ignore_word)
    if a.json:
        print(json.dumps(findings, ensure_ascii=False, indent=2))
    else:
        for x in findings:
            print(f"{x['file']}:{x['line']}: [{x['level']}] {x['code']} {x['message']}")
    errors = sum(1 for x in findings if x["level"] == "ERROR")
    warns = sum(1 for x in findings if x["level"] == "WARN")
    if not a.json:
        print(f"\nERROR {errors} / WARN {warns}（合否の判断は人が行う）")
    sys.exit(1 if errors or (a.strict and warns) else 0)


if __name__ == "__main__":
    main()
