#!/usr/bin/env python3
"""trace_check.py - 要求ID と テストケース の対応の抜けを検出する補助。合否は判断しない。

使い方:
    python trace_check.py --spec docs/spec --test docs/test
    python trace_check.py --spec docs/spec --test docs/test --md        # トレーサビリティ表をMarkdownで出力
    python trace_check.py --spec docs/spec --test docs/test --defs-from tests   # テストコード中の TC-ID も「定義」として数える

考え方:
    テストケース(TC)が「定義されている」とは、次のいずれかを指す。
      - 見出し    : "# TC-002 題名"
      - 表の行頭  : "| TC-002 | FR-001 | 境界値 | ... |"（先頭セルがTC-ID）
      - --defs-from で指定したフォルダ（テストコード等）のどこかにTC-IDがある
    トレーサビリティ表（"| FR-001 | CSV | TC-001〜TC-003 | 未実施 |"）に名前があるだけのTCは「参照」で、
    定義ではない。参照だけで「テストあり」と判定すると、実体のないテストで抜けを見逃すため。

検出するもの:
    T001 定義済みのテストが1つもない要求ID
    T002 存在しない要求IDを参照しているテスト
    T003 要求IDを参照していないテストケース（孤立）
    T004 表に名前があるだけで、定義が見つからないテストケース（実体なし）
"""
import argparse
import re
import sys
from collections import defaultdict
from pathlib import Path

PREFIXES = "FR|NFR|IR|CR|SR"
# 日本語の助詞・句読点が隣接しても検出できるよう、\b ではなく英数字だけを境界にする
REQ_ID = re.compile(r"(?<![A-Za-z0-9-])((?:" + PREFIXES + r")-\d{1,6})(?![0-9])")
REQ_HEADING = re.compile(r"^#{1,6}\s+((?:" + PREFIXES + r")-\d{1,6})(?![0-9A-Za-z])")
TC_ID = re.compile(r"(?<![A-Za-z0-9-])(TC-\d{1,6})(?![0-9])")
TC_RANGE = re.compile(r"(?<![A-Za-z0-9-])TC-(\d{1,6})\s*[〜～~\-–]\s*(?:TC-)?(\d{1,6})(?![0-9])")
FENCE = re.compile(r"^\s*(```|~~~)")


def read_text(path):
    return Path(path).read_text(encoding="utf-8-sig")


def expand_tcs(line):
    """行内のTC-IDを返す。『TC-001〜TC-005』のような範囲は展開する（上限1000件）。"""
    found = list(TC_ID.findall(line))
    for m in TC_RANGE.finditer(line):
        lo, hi = m.group(1), m.group(2)
        width = max(len(lo), 3)
        a, b = int(lo), int(hi)
        if a <= b and b - a <= 1000:
            found.extend(f"TC-{n:0{width}d}" for n in range(a, b + 1))
    return list(dict.fromkeys(found))


def spec_ids(spec_dir):
    ids = {}
    for f in sorted(Path(spec_dir).rglob("*.md")):
        in_fence = False
        for i, ln in enumerate(read_text(f).splitlines(), start=1):
            if FENCE.match(ln):
                in_fence = not in_fence
                continue
            if in_fence:
                continue
            m = REQ_HEADING.match(ln)
            if m:
                ids.setdefault(m.group(1), f"{f}:{i}")
    return ids


def first_cell(row):
    cells = [c.strip() for c in row.strip().strip("|").split("|")]
    return cells[0] if cells else ""


def scan_tests(test_dir):
    """tc -> 対応要求の集合 / tc -> 位置 / 定義済みtcの集合"""
    tc_req = defaultdict(set)
    tc_pos = {}
    defined = set()
    for f in sorted(Path(test_dir).rglob("*.md")):
        in_fence = False
        current_tc = None
        for i, ln in enumerate(read_text(f).splitlines(), start=1):
            if FENCE.match(ln):
                in_fence = not in_fence
                continue
            if in_fence:
                continue
            tcs = expand_tcs(ln)
            stripped = ln.lstrip()
            is_heading = stripped.startswith("#")
            is_row = stripped.startswith("|")
            if tcs and (is_heading or is_row):
                for tc in tcs:
                    tc_pos.setdefault(tc, f"{f}:{i}")
                    tc_req[tc]  # 登録
                reqs = REQ_ID.findall(ln)
                if is_row:
                    head = first_cell(ln)
                    if TC_ID.fullmatch(head):  # 先頭セルがTC-ID＝テストケースの定義行
                        defined.add(head)
                    for r in reqs:
                        for tc in tcs:
                            tc_req[tc].add(r)
                    current_tc = None
                else:
                    current_tc = tcs[0]
                    defined.add(current_tc)
                    for r in reqs:
                        tc_req[current_tc].add(r)
                continue
            if current_tc:
                if stripped.startswith("#"):
                    current_tc = None
                    continue
                for r in REQ_ID.findall(ln):
                    tc_req[current_tc].add(r)
    return tc_req, tc_pos, defined


def scan_defs_from(dirs):
    """テストコード等のフォルダ内にあるTC-IDを『定義』として数える。"""
    defined = set()
    for d in dirs:
        for f in Path(d).rglob("*"):
            if f.is_file() and f.stat().st_size < 2_000_000:
                try:
                    text = f.read_text(encoding="utf-8-sig")
                except (UnicodeDecodeError, OSError):
                    continue
                defined.update(TC_ID.findall(text))
    return defined


def main():
    ap = argparse.ArgumentParser(description="要求IDとテストの対応の抜けを検出（補助）")
    ap.add_argument("--spec", required=True)
    ap.add_argument("--test", required=True)
    ap.add_argument("--defs-from", action="append", default=[], metavar="DIR",
                    help="TC-IDが書かれたテストコード等のフォルダ（複数指定可）。ここにあるTC-IDは定義済みとみなす")
    ap.add_argument("--allow-undefined-tc", action="store_true",
                    help="T004（定義の見つからないTC）をエラーでなく警告にする")
    ap.add_argument("--md", action="store_true", help="トレーサビリティ表をMarkdownで出力")
    a = ap.parse_args()

    ids = spec_ids(a.spec)
    tc_req, tc_pos, defined = scan_tests(a.test)
    defined |= scan_defs_from(a.defs_from)
    req_tc = defaultdict(set)
    for tc, rs in tc_req.items():
        for r in rs:
            req_tc[r].add(tc)

    problems = 0
    if not ids:
        print(f"{a.spec}: [ERROR] T000 要求が1件も検出できません（要求は「## FR-001 名前」の見出し形式で書く）")
        problems += 1
    for rid in sorted(ids):
        covered = [tc for tc in req_tc.get(rid, ()) if tc in defined]
        if not covered:
            note = "（表に名前だけの参照あり）" if req_tc.get(rid) else ""
            print(f"{ids[rid]}: [ERROR] T001 {rid} に定義済みのテストがありません{note}")
            problems += 1
    for tc in sorted(tc_req):
        for r in sorted(r for r in tc_req[tc] if r not in ids):
            print(f"{tc_pos[tc]}: [ERROR] T002 {tc} が存在しない要求 {r} を参照しています")
            problems += 1
        if not tc_req[tc]:
            print(f"{tc_pos[tc]}: [WARN] T003 {tc} が要求IDを参照していません（孤立）")
        if tc not in defined:
            level = "WARN" if a.allow_undefined_tc else "ERROR"
            print(f"{tc_pos[tc]}: [{level}] T004 {tc} の定義が見つかりません（表に名前があるだけ）")
            if not a.allow_undefined_tc:
                problems += 1

    if a.md:
        print("\n| 要求ID | テストケース | 結果 |\n|---|---|---|")
        for rid in sorted(ids):
            cells = [tc if tc in defined else f"{tc}（未定義）" for tc in sorted(req_tc.get(rid, []))]
            print(f"| {rid} | {', '.join(cells) or '（なし）'} | 未実施 |")

    print(f"\n要求 {len(ids)} 件／テストケース {len(tc_req)} 件（定義済み {len(defined & set(tc_req))} 件）／"
          f"問題 {problems} 件（合否の判断は人が行う）")
    sys.exit(1 if problems else 0)


if __name__ == "__main__":
    main()
