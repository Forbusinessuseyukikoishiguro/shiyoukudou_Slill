#!/usr/bin/env python3
"""spec_lint.py - 仕様書(.md)の機械的な点検。見落とし防止の補助であり、合否は判断しない。

使い方:
    python spec_lint.py docs/spec            # 点検して一覧表示
    python spec_lint.py docs/spec --strict   # 警告もエラー扱い（終了コード1）
    python spec_lint.py docs/spec --json     # JSON出力

検出するもの:
    E001 要求IDの重複
    E002 受入基準がない
    W001 曖昧語（など／適切に／必要に応じて／速く 等）
    W002 義務表現がない（なければならない／ものとする／望ましい／てもよい／すること）
    I001 受入基準が Given/When/Then 形式でない
    I002 複合要求の可能性（および／かつ 等。単一性を人が確認）
    I003 文書の版・状態のメタ情報がない
    I004 未決事項の件数
"""
import argparse
import json
import re
import sys
from pathlib import Path

REQ_HEADING = re.compile(r"^(#{1,6})\s+((?:FR|NFR|IR|CR|SR)-\d{1,6})\b\s*(.*)$")
ANY_HEADING = re.compile(r"^(#{1,6})\s+\S")
FENCE = re.compile(r"^\s*(```|~~~)")

AMBIGUOUS = [
    "など", "等", "適切に", "適宜", "必要に応じて", "できるだけ", "なるべく",
    "速く", "素早く", "迅速", "使いやすい", "分かりやすい", "わかりやすい",
    "十分", "柔軟", "容易に", "簡単に", "高速", "大量", "少量", "ある程度",
    "基本的に", "原則として", "場合によって", "一般的に",
]
OBLIGATION = ["なければならない", "ものとする", "望ましい", "てもよい", "すること"]
COMPOUND = ["および", "及び", "かつ", "ならびに", "並びに", "とともに"]
ACCEPT_WORDS = ["受入基準", "Given", "given"]


def strip_code(lines):
    """コードブロックの中身を空行に置き換える（行番号は保つ）。"""
    out, in_fence = [], False
    for ln in lines:
        if FENCE.match(ln):
            in_fence = not in_fence
            out.append("")
            continue
        out.append("" if in_fence else ln)
    return out


def parse_requirements(path):
    raw = path.read_text(encoding="utf-8").splitlines()
    lines = strip_code(raw)
    reqs, cur = [], None
    for i, ln in enumerate(lines, start=1):
        m = REQ_HEADING.match(ln)
        if m:
            if cur:
                cur["end"] = i - 1
                reqs.append(cur)
            cur = {"id": m.group(2), "title": m.group(3).strip(), "line": i,
                   "level": len(m.group(1)), "body": [], "end": i}
            continue
        if cur and ANY_HEADING.match(ln):
            hl = len(ln) - len(ln.lstrip("#"))
            if hl <= cur["level"]:
                cur["end"] = i - 1
                reqs.append(cur)
                cur = None
                continue
        if cur:
            cur["body"].append((i, ln))
    if cur:
        cur["end"] = len(lines)
        reqs.append(cur)
    return raw, lines, reqs


def lint(spec_dir, strict=False):
    findings = []
    files = sorted(Path(spec_dir).rglob("*.md"))
    if not files:
        findings.append({"level": "ERROR", "code": "E000", "file": str(spec_dir), "line": 0,
                         "message": "仕様 .md が見つかりません"})
        return findings, 0
    seen = {}
    total_reqs = 0
    open_items = 0
    for f in files:
        raw, lines, reqs = parse_requirements(f)
        text_all = "\n".join(lines)
        if not re.search(r"^(版|状態)\s*[:：]", text_all, re.M):
            findings.append({"level": "INFO", "code": "I003", "file": str(f), "line": 1,
                             "message": "版・状態のメタ情報（版:／状態:）が見つかりません"})
        in_open = False
        for ln in lines:
            if re.match(r"^#{1,6}\s+.*未決事項", ln):
                in_open = True
                continue
            if in_open and ANY_HEADING.match(ln):
                in_open = False
            if in_open and re.match(r"^\s*([-*]|\|\s*Q-\d+|\d+\.)\s*\S", ln) and "---" not in ln:
                open_items += 1
        for r in reqs:
            total_reqs += 1
            rid = r["id"]
            if rid in seen:
                findings.append({"level": "ERROR", "code": "E001", "file": str(f), "line": r["line"],
                                 "message": f"{rid} が重複しています（先の定義: {seen[rid]}）"})
            else:
                seen[rid] = f"{f}:{r['line']}"
            body = "\n".join(t for _, t in r["body"])
            head_and_body = (r["title"] + "\n" + body)
            if not any(w in body for w in ACCEPT_WORDS):
                findings.append({"level": "ERROR", "code": "E002", "file": str(f), "line": r["line"],
                                 "message": f"{rid} に受入基準がありません"})
            elif "Given" not in body and "given" not in body:
                findings.append({"level": "INFO", "code": "I001", "file": str(f), "line": r["line"],
                                 "message": f"{rid} の受入基準が Given/When/Then 形式ではありません"})
            if not any(w in head_and_body for w in OBLIGATION):
                findings.append({"level": "WARN", "code": "W002", "file": str(f), "line": r["line"],
                                 "message": f"{rid} に義務表現（しなければならない 等）がありません"})
            for lineno, t in r["body"]:
                for w in AMBIGUOUS:
                    if w in t:
                        findings.append({"level": "WARN", "code": "W001", "file": str(f), "line": lineno,
                                         "message": f"{rid} に曖昧語「{w}」: {t.strip()[:60]}"})
                        break
            first = next((t for _, t in r["body"] if t.strip()), "")
            first_sentence = first.split("。")[0]
            hit = next((w for w in COMPOUND if w in first), None)
            if hit is None and re.search(r"[しみきりびちい]、", first_sentence):
                hit = "連用形の並列"
            if hit:
                findings.append({"level": "INFO", "code": "I002", "file": str(f), "line": r["line"],
                                 "message": f"{rid} は複合要求の可能性（{hit}）。単一か人が確認"})
    findings.append({"level": "INFO", "code": "I004", "file": str(spec_dir), "line": 0,
                     "message": f"要求 {total_reqs} 件／未決事項 {open_items} 件（概算）"})
    return findings, total_reqs


def main():
    ap = argparse.ArgumentParser(description="仕様 .md の機械的な点検（補助）")
    ap.add_argument("spec_dir")
    ap.add_argument("--strict", action="store_true", help="警告もエラー扱いにする")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    findings, _ = lint(a.spec_dir, a.strict)
    if a.json:
        print(json.dumps(findings, ensure_ascii=False, indent=2))
    else:
        for x in findings:
            print(f"{x['file']}:{x['line']}: [{x['level']}] {x['code']} {x['message']}")
    errors = sum(1 for x in findings if x["level"] == "ERROR")
    warns = sum(1 for x in findings if x["level"] == "WARN")
    if not a.json:
        print(f"\nERROR {errors} / WARN {warns}（合否の判断は人が行う）")
    sys.exit(1 if errors or (a.strict and warns) else 0)


if __name__ == "__main__":
    main()
