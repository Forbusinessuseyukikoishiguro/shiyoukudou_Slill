#!/usr/bin/env python3
"""trace_check.py - 要求ID と テストケース の対応の抜けを検出する補助。合否は判断しない。

使い方:
    python trace_check.py --spec docs/spec --test docs/test
    python trace_check.py --spec docs/spec --test docs/test --md   # トレーサビリティ表をMarkdownで出力

検出するもの:
    T001 テストが1つもない要求ID
    T002 存在しない要求IDを参照しているテスト
    T003 要求IDを参照していないテストケース（孤立）

テストの書き方（どちらでも可）:
    表:     | TC-001 | FR-001 | 境界値 | ... |            （同じ行に要求IDがあればよい）
    見出し: # TC-002 ...  の次の行以降に「対応要求：FR-001」
"""
import argparse
import re
import sys
from collections import defaultdict
from pathlib import Path

REQ_ID = re.compile(r"\b((?:FR|NFR|IR|CR|SR)-\d{1,6})\b")
REQ_HEADING = re.compile(r"^#{1,6}\s+((?:FR|NFR|IR|CR|SR)-\d{1,6})\b")
TC_ID = re.compile(r"\b(TC-\d{1,6})\b")
FENCE = re.compile(r"^\s*(```|~~~)")


def spec_ids(spec_dir):
    ids = {}
    for f in sorted(Path(spec_dir).rglob("*.md")):
        in_fence = False
        for i, ln in enumerate(f.read_text(encoding="utf-8").splitlines(), start=1):
            if FENCE.match(ln):
                in_fence = not in_fence
                continue
            if in_fence:
                continue
            m = REQ_HEADING.match(ln)
            if m:
                ids.setdefault(m.group(1), f"{f}:{i}")
    return ids


def test_map(test_dir):
    """tc -> set(req ids)、tc -> 位置"""
    tc_req = defaultdict(set)
    tc_pos = {}
    for f in sorted(Path(test_dir).rglob("*.md")):
        in_fence = False
        current_tc = None
        for i, ln in enumerate(f.read_text(encoding="utf-8").splitlines(), start=1):
            if FENCE.match(ln):
                in_fence = not in_fence
                continue
            if in_fence:
                continue
            tcs = TC_ID.findall(ln)
            is_heading = ln.lstrip().startswith("#")
            is_row = ln.lstrip().startswith("|")
            if tcs and (is_heading or is_row):
                for tc in tcs:
                    tc_pos.setdefault(tc, f"{f}:{i}")
                    tc_req[tc]  # 登録
                if is_row:
                    for r in REQ_ID.findall(ln):
                        for tc in tcs:
                            tc_req[tc].add(r)
                    current_tc = None
                else:
                    current_tc = tcs[0]
                    for r in REQ_ID.findall(ln):
                        tc_req[current_tc].add(r)
                continue
            if current_tc:
                if ln.lstrip().startswith("#"):
                    current_tc = None
                    continue
                for r in REQ_ID.findall(ln):
                    tc_req[current_tc].add(r)
    return tc_req, tc_pos


def main():
    ap = argparse.ArgumentParser(description="要求IDとテストの対応の抜けを検出（補助）")
    ap.add_argument("--spec", required=True)
    ap.add_argument("--test", required=True)
    ap.add_argument("--md", action="store_true", help="トレーサビリティ表をMarkdownで出力")
    a = ap.parse_args()

    ids = spec_ids(a.spec)
    tc_req, tc_pos = test_map(a.test)
    req_tc = defaultdict(set)
    for tc, rs in tc_req.items():
        for r in rs:
            req_tc[r].add(tc)

    problems = 0
    for rid in sorted(ids):
        if not req_tc.get(rid):
            print(f"{ids[rid]}: [ERROR] T001 {rid} にテストがありません")
            problems += 1
    for tc in sorted(tc_req):
        unknown = sorted(r for r in tc_req[tc] if r not in ids)
        for r in unknown:
            print(f"{tc_pos[tc]}: [ERROR] T002 {tc} が存在しない要求 {r} を参照しています")
            problems += 1
        if not tc_req[tc]:
            print(f"{tc_pos[tc]}: [WARN] T003 {tc} が要求IDを参照していません（孤立）")

    if a.md:
        print("\n| 要求ID | テストケース | 結果 |\n|---|---|---|")
        for rid in sorted(ids):
            tcs = ", ".join(sorted(req_tc.get(rid, []))) or "（なし）"
            print(f"| {rid} | {tcs} | 未実施 |")

    print(f"\n要求 {len(ids)} 件／テストケース {len(tc_req)} 件／問題 {problems} 件（合否の判断は人が行う）")
    sys.exit(1 if problems else 0)


if __name__ == "__main__":
    main()
