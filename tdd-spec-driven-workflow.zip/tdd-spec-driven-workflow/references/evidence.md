# TDD研究の知見と読み方

注意：書誌情報は作成時の知識に基づく。公開物で引用する前に、DOI/出版社ページで巻号・ページを確認すること。確認できないものは書かない。

## 論文

1. Erdogmus, H., Morisio, M., & Torchiano, M. (2005). On the effectiveness of the test-first approach to programming. IEEE Transactions on Software Engineering, 31(3).
   - テストファースト群は、テスト作成量が多い傾向。品質・生産性への効果は一貫して確認されなかった、という趣旨の報告。
2. Rafique, Y., & Mišić, V. B. (2013). The effects of test-driven development on external quality and productivity: a meta-analysis. IEEE Transactions on Software Engineering, 39(6).
   - メタ分析。品質への効果は小さな改善の傾向があるが、研究間のばらつきが大きく、生産性への影響は一貫しない、という趣旨。
3. Fucci, D., et al. (2017). A dissection of the test-driven development process: does it really matter to test-first or to test-last? IEEE Transactions on Software Engineering, 43(7).
   - 効果の要因は「テストを先に書くこと」そのものより、短いサイクルで小さく進める粒度・一貫性にある可能性を示唆。
4. Karac, I., & Turhan, B. (2018). What do we (really) know about test-driven development? IEEE Software, 35(4).
   - 実証研究を概観し、TDDの効果について確実に言えることは限られる、という整理。

5. Nagappan, N., Maximilien, E. M., Bhat, T., & Williams, L. (2008). Realizing quality improvement through test driven development: results and experiences of four industrial teams. Empirical Software Engineering, 13(3).
   - 産業界の4チームの事例で、TDD適用チームの出荷前の欠陥密度が大きく下がったと報告。一方、初期の開発時間は増えた。条件の異なる4事例である点を断る。
6. Mens, T., & Tourwé, T. (2004). A survey of software refactoring. IEEE Transactions on Software Engineering, 30(2).
   - リファクタリング（外から見える挙動を変えない構造改善）の整理。Refactorフェーズの定義の根拠。

## テストの強さ・AIコードの確認（補助）

7. Inozemtseva, L., & Holmes, R. (2014). Coverage is not strongly correlated with test suite effectiveness. Proc. ICSE 2014.
8. Just, R., et al. (2014). Are mutants a valid substitute for real faults in software testing? Proc. FSE 2014.
   - 「全件通った」「カバレッジが高い」だけでは、テストの強さは分からない。重要箇所は変異テストで点検する提案の根拠。
9. Perry, N., et al. (2023). Do users write more insecure code with AI assistants? ACM CCS 2023.
   - AIコード支援の利用者は、安全でないコードを書きやすく、自分のコードを安全と考えやすい傾向が報告されている。
10. Zheng, L., et al. (2023). Judging LLM-as-a-judge with MT-Bench and Chatbot Arena. NeurIPS 2023.
    - LLMによる評価のバイアスが報告されている。AIレビューは補助とし、判断は人。
11. Parasuraman, R., & Manzey, D. H. (2010). Complacency and bias in human use of automation: an attentional integration. Human Factors, 52(3).
    - 自動化の出力を過信しやすい傾向。

（9〜11は、ユーザーの記事「仕様駆動開発」で引用されているもの。）

## 読み方（このSkillの設計への反映）

1. 結果は混在している。「TDDで品質が上がる」と断定しない。
2. 効果が出る条件として、小さなステップ・一貫した実施が示唆される。Skillが「要求ID1〜2件ずつ」「Redを見る」「最小実装」「1回に1つの改善」を求める根拠の一つ。ただし、これらが成果を保証するわけではない。
3. 調査対象（学生／企業、課題規模、期間）は研究により異なる。自社・自案件への外挿は、計測して確かめる（不具合数、手戻り、レビュー指摘など）。
4. 仕様→テスト→実装の追跡可能性（要求ID、受入基準）は、TDD研究とは別の根拠（要求工学・テスト工学の規格・文献）に基づく。規格は考え方の参考で、準拠の証明ではない。
