# 言語・FW別の実行コマンドと注意点

コマンドは代表例。プロジェクトの `package.json` / `pyproject.toml` / `Makefile` の定義を優先する。

## JavaScript / TypeScript

| 目的 | Vitest | Jest | Node標準 |
|---|---|---|---|
| 全件 | `npx vitest run` | `npx jest --ci` | `node --test "tests/unit/**/*.test.mjs"` |
| 単一ファイル | `npx vitest run path/to/x.test.ts` | `npx jest path/to/x.test.ts` | `node --test path/to/x.test.mjs` |
| 名前で絞る | `npx vitest run -t "TC-002"` | `npx jest -t "TC-002"` | `node --test --test-name-pattern="TC-002"` |
| 監視 | `npx vitest` | `npx jest --watch` | `node --test --watch` |

注意
1. Node標準の `--test` は、環境によってディレクトリ指定が通らないことがある。グロブを引用符で囲む（PowerShellでも）。
2. Playwright：既定のタイムアウトが長い。Redの確認が遅いときは、設定で `timeout` と `expect.timeout` を短くする（例：10秒／3秒）。変更は人に伝える。
3. E2Eは、ビルド成果物を使う場合、実行前にビルドが走る構成にする。ビルド失敗をRedと取り違えない。
4. Playwrightの絞り込み：`npx playwright test <file> -g "E-06"`。

## Python

| 目的 | pytest |
|---|---|
| 全件 | `pytest -q` |
| 単一ファイル | `pytest tests/test_x.py -q` |
| 名前で絞る | `pytest -k "tc_002" -q` |
| 直前の失敗のみ | `pytest --lf -q` |
| 最初の失敗で停止 | `pytest -x -q` |

注意：インポートエラー（ModuleNotFoundError）はRedではない。スタブを置いてアサーション失敗にする。

## Java

| 目的 | Maven | Gradle |
|---|---|---|
| 全件 | `mvn -q test` | `./gradlew test` |
| 単一クラス | `mvn -q -Dtest=XTest test` | `./gradlew test --tests XTest` |

注意：コンパイルエラーはRedではない。メソッドのシグネチャだけ作り、`UnsupportedOperationException` 等で未実装にしてアサーション失敗にする。

## Go / その他

1. Go：`go test ./...` ／ `go test -run TC002 ./pkg/...`
2. PHP：`vendor/bin/phpunit` ／ `--filter`
3. .NET：`dotnet test` ／ `--filter`

## Red確認のチェック

1. 終了コードが0でない
2. 失敗メッセージが「期待値と実際の不一致」である
3. 失敗が今回追加したテストに限られる
4. 「テストが見つからない」「0件実行」は失敗でも成功でもない。コマンドとパスを直す
5. 構文・import・設定・コンパイル・ビルドの失敗はRedではない（`scripts/tdd_gate.sh red` が疑いとして知らせる）
6. 最初の失敗で止まるオプション（`--bail`、`-x`）は、Redで全件の失敗を見たいときは使わない。Green中の絞り込みでは有用
7. 最初から通ったテストは、何を守るか理由を記録する

## Green確認のチェック

1. 対象テストが通る
2. 全件が通る（skip数が増えていない）
3. 警告・非推奨の新規増加がない
4. 「0件実行」でない（件数を実行出力から確認する）

## Refactor後の追加確認

1. 実行順のランダム化・並列度の変更を一度かけると、順序依存を見つけやすい
2. 結果が実行ごとに変わる場合はGreenとみなさず、[[qa-verification-runner]] のフレイキー検出へ
