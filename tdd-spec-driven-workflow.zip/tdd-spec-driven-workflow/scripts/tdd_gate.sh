#!/usr/bin/env bash
# TDDフェーズ別の実行ゲート。テストを実行し、フェーズに合った結果かを判定する。
# 使い方: scripts/tdd_gate.sh <red|green|refactor> <テストコマンド...>
# 例:     scripts/tdd_gate.sh red npx vitest run
#         scripts/tdd_gate.sh green pytest -q
# 終了コード:
#   0 : 期待どおり（red=正しそうな失敗 / green・refactor=全件成功）
#   1 : green/refactor で失敗あり
#   2 : 使い方の誤り
#   3 : red で失敗したが、構文・import・コンパイル・テスト未検出など「Redとして不適切」の疑い
#   4 : red のはずが成功（最初から全件通っている。何を守るテストか確認する）
#   5 : 成功したがテストが0件の疑い（偽のGreen）
# 注意: 判定はヒューリスティック。最終確認は出力を人が読む。本番環境では実行しない。
set -u

usage() { echo "usage: $0 <red|green|refactor> <test command...>" >&2; }

phase="${1:-}"
if [ -z "$phase" ] || [ $# -lt 2 ]; then usage; exit 2; fi
shift
case "$phase" in red|green|refactor) ;; *) usage; exit 2;; esac

tmp="$(mktemp)"
trap 'rm -f "$tmp"' EXIT

"$@" >"$tmp" 2>&1
rc=$?

tail -n 40 "$tmp"
echo "----"
echo "phase=${phase} exit=${rc}"

suspicious='SyntaxError|ModuleNotFoundError|ImportError|Cannot find module|does not provide an export|command not found|No tests found|no tests found|collected 0 items|error TS[0-9]+|COMPILATION ERROR|compilation failed|cannot find symbol|undefined: '
zero_tests='collected 0 items|No tests found|no tests found|Ran 0 tests|no tests to run|# tests 0|0 passed, 0 total|Tests: *0 total'

if [ "$phase" = "red" ]; then
  if [ "$rc" -eq 0 ]; then
    echo "RESULT: 想定外 - 全件成功。最初から通るテストは『何を守るか』を記録するか、テストを見直す。"
    exit 4
  fi
  if grep -Eq "$suspicious" "$tmp"; then
    echo "RESULT: 失敗しているが、構文/import/コンパイル/未検出の疑い。Redとして正しい理由か確認する（コンパイル言語は空実装を作ってアサーション失敗にする）。"
    exit 3
  fi
  echo "RESULT: OK - 失敗を確認。失敗理由が『仕様を満たしていない』ものか出力で確認する。"
  exit 0
fi

# green / refactor
if [ "$rc" -ne 0 ]; then
  echo "RESULT: 失敗あり。直前の変更を見直す（テストを弱めて通さない）。"
  exit 1
fi
if grep -Eiq "$zero_tests" "$tmp"; then
  echo "RESULT: 成功扱いだがテストが0件の疑い。コマンド・パスを確認する。"
  exit 5
fi
echo "RESULT: OK - 全件成功。"
exit 0
