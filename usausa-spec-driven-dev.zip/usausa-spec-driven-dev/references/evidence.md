# 根拠とする研究

注意：書誌情報は作成時の知識に基づく。商用公開（Kindle・Qiita・研修資料）で引用する前に、DOI・出版社ページで題名・巻号・ページを必ず確認する。確認できないものは書かない。論文は「考え方の背景」であり、最新のモデルやClaude Codeでの効果を直接保証しない。「〜という知見が報告されている」と書く。

## プロンプト・仕様の渡し方

1. Wei, J., et al. (2022). Chain-of-thought prompting elicits reasoning in large language models. NeurIPS 2022.
   - 段階的な推論の例を示すと推論課題の性能が上がると報告。示唆：先に「計画」を書かせる。
2. Kojima, T., Gu, S. S., Reid, M., Matsuo, Y., & Iwasawa, Y. (2022). Large language models are zero-shot reasoners. NeurIPS 2022.
   - 例なしでも「段階的に考えよう」と促すだけで改善する場合があると報告。
3. Wang, X., et al. (2023). Self-consistency improves chain of thought reasoning in language models. ICLR 2023.
   - 複数の推論経路から多数決。示唆：重要な判断は複数案を比較。
4. Liu, N. F., et al. (2024). Lost in the middle: how language models use long contexts. TACL, 12.
   - 長い文脈では、途中の情報が使われにくい傾向。示唆：重要な制約は先頭か末尾にも置く。
5. Sclar, M., et al. (2024). Quantifying language models' sensitivity to spurious features in prompt design. ICLR 2024.
   - プロンプトの書式の違いで性能が大きくぶれうる。示唆：書式を固定し、変更時は再評価。

## 人が確認・評価する理由

6. Perry, N., et al. (2023). Do users write more insecure code with AI assistants? ACM CCS 2023.
   - AIコード支援の利用者は、安全でないコードを書きやすく、自分のコードを安全と考えやすい傾向。
7. Zheng, L., et al. (2023). Judging LLM-as-a-judge with MT-Bench and Chatbot Arena. NeurIPS 2023.
   - LLMによる評価のバイアスが報告されている。AIレビューは補助。
8. Parasuraman, R., & Manzey, D. H. (2010). Complacency and bias in human use of automation: an attentional integration. Human Factors, 52(3).
   - 自動化の出力を過信しやすい傾向。

## レビュー

9. Fagan, M. E. (1976). Design and code inspections to reduce errors in program development. IBM Systems Journal, 15(3).
   - インスペクションが欠陥の早期発見に有効。
10. Bacchelli, A., & Bird, C. (2013). Expectations, outcomes, and challenges of modern code review. Proc. ICSE 2013.
    - 現代のコードレビューは、欠陥発見だけでなく知識共有・理解の促進も成果。

## 学習

11. Roediger, H. L., & Karpicke, J. D. (2006). Test-enhanced learning: taking memory tests improves long-term retention. Psychological Science, 17(3).
    - 思い出す作業が記憶の定着に有効。理解度テストは「先に自分で答えを考えてから答えを開く」形にする。

## 読み方

1. 結果は特定のモデル・課題での報告。自分の仕様・モデルで評価して確かめる。
2. 仕様→テスト→実装の追跡可能性は、要求工学・テスト工学の規格・文献に基づく（standards-map.md）。TDDの研究は [[tdd-spec-driven-workflow]] の evidence.md。
