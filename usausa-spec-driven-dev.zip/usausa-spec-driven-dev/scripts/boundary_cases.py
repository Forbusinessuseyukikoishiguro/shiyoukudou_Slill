#!/usr/bin/env python3
"""境界値分析のテストケース表と、デシジョンテーブルの骨組みを Markdown で出力する。

使い方:
  boundary_cases.py boundary --req FR-001 --lower 0 --upper 1000 --unit 行 \
      --start 1 --in-expect "読み込める" --out-expect "「行数超過」を表示し終了コード1"
  boundary_cases.py decision --cond "文字コードがUTF-8" --cond "行数が1000以内"

仕様:
  boundary : 下限の直前・ちょうど・直後、上限の直前・ちょうど・直後の最大6値を作る。
             下限が0以上のときは負の値を「入力できない値」として除く（--allow-negative で解除）。
             値が重複する場合は最初の1つだけ残す。範囲内/外で期待結果を切り替える。
  decision : 条件(1〜4個)のY/Nの全組み合わせ。結果の行は「（人が決める）」。
             期待結果は仕様（受入基準）から人が決める。AIが推測で埋めない。
"""
import argparse
import sys


def boundary(a):
    if a.lower > a.upper:
        sys.exit("error: --lower は --upper 以下にしてください")
    cands = [
        (a.lower - 1, "下限の直前"),
        (a.lower, "下限ちょうど"),
        (a.lower + 1, "下限の直後"),
        (a.upper - 1, "上限の直前"),
        (a.upper, "上限ちょうど"),
        (a.upper + 1, "上限の直後"),
    ]
    non_negative = a.lower >= 0 and not a.allow_negative
    seen, rows = set(), []
    dropped_negative = False
    for v, label in cands:
        if non_negative and v < 0:
            dropped_negative = True
            continue
        if v in seen:
            continue
        seen.add(v)
        exp = a.in_expect if a.lower <= v <= a.upper else a.out_expect
        rows.append((v, label, exp))
    out = ["| テストID | 対応要求 | 技法 | 入力値 | 観点 | 期待結果 |",
           "|---|---|---|---|---|---|"]
    for i, (v, label, exp) in enumerate(rows):
        out.append(f"| TC-{a.start + i:03d} | {a.req} | 境界値分析 | {v}{a.unit} | {label} | {exp} |")
    print("\n".join(out))
    if dropped_negative:
        print("\n> 下限が0以上のため、負の値（下限の直前）は入力できない値として除いています。")


def decision(a):
    n = len(a.cond)
    if not 1 <= n <= 4:
        sys.exit("error: 条件は1〜4個にしてください")
    cols = 2 ** n
    head = "| 条件 | " + " | ".join(f"ケース{i + 1}" for i in range(cols)) + " |"
    sep = "|---|" + "---|" * cols
    out = [head, sep]
    for ci, name in enumerate(a.cond):
        # 先頭の条件が最も遅く変化する（Y,Y / Y,N / N,Y / N,N の順）
        block = cols // (2 ** (ci + 1))
        cells = ["Y" if (k // block) % 2 == 0 else "N" for k in range(cols)]
        out.append(f"| {name} | " + " | ".join(cells) + " |")
    out.append("| **結果** | " + " | ".join(["（人が決める）"] * cols) + " |")
    print("\n".join(out))
    print("\n> 複数の条件が同時に失敗したときの優先順位は、仕様に書かれていないことが多い穴です。"
          "決めるのは人です（決定記録 DEC に残す）。")


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("boundary")
    b.add_argument("--req", required=True)
    b.add_argument("--lower", type=int, required=True)
    b.add_argument("--upper", type=int, required=True)
    b.add_argument("--unit", default="")
    b.add_argument("--start", type=int, default=1)
    b.add_argument("--in-expect", dest="in_expect", required=True)
    b.add_argument("--out-expect", dest="out_expect", required=True)
    b.add_argument("--allow-negative", action="store_true")
    b.set_defaults(fn=boundary)
    d = sub.add_parser("decision")
    d.add_argument("--cond", action="append", required=True)
    d.set_defaults(fn=decision)
    a = p.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
